# import libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn import datasets, ensemble
from sklearn.metrics import r2_score
from sklearn.metrics import mean_squared_error
import plotly.express as px

import streamlit as st

# load the data


'''
# in this project we will predict traffic volume given these weather conditions.
'''
st.sidebar.title("Regression on Metro Interstate Traffic Volume")
st.sidebar.header("Options")
if st.sidebar.checkbox('Show the dataset as table data'):

    raw = pd.read_csv('data/Metro_Interstate_Traffic_Volume.csv')
    st.subheader("display first five rows")
    st.write(raw.head())

if st.sidebar.checkbox('EDA'):
    st.subheader("EDA")
    df_traffic_data=pd.read_csv('data/Metro_Interstate_Traffic_Volume.csv')
    '''## shape of the data'''
    st.write(df_traffic_data.shape)
    '''## data describing'''
    st.write(df_traffic_data.describe())
    '''## Analysis'''
    
    
    '''### Plotting frequency of each category in holiday column'''
    fig=plt.figure(figsize = (8,6))
    sns.countplot(y='holiday', data = df_traffic_data)
    st.pyplot(fig)
    
    '''### 'None' is far greater than the other days. Removing None data to visualize the others'''
    holidays = df_traffic_data.loc[df_traffic_data.holiday != 'None']
    fig=plt.figure(figsize=(8,6))
    sns.countplot(y='holiday', data= holidays)
    st.pyplot(fig)
    
    '''### plotting distribution of temperature variable'''
    fig=plt.figure(figsize=(6,4))
    sns.boxplot('temp', data = df_traffic_data)
    st.pyplot(fig)
    
    '''### Plotting rain variable'''
    fig=plt.figure(figsize=(6,4))
    sns.distplot(df_traffic_data.rain_1h)
    st.pyplot(fig)
    st.write("From the distribution, it shows that the data is extremely skewed. Most of the observations are concentrated around 0.")
    '''### clouds_all indicates the cloud coverage for the give day and hour'''
    fig=plt.figure(figsize=(6,4))
    sns.distplot(df_traffic_data.clouds_all)
    st.pyplot(fig)
    '''### exploring different categories in weather_main'''
    fig=plt.figure(figsize=(6,4))
    sns.countplot(y='weather_main', data=df_traffic_data)
    st.pyplot(fig)
    '''### exploring different categories in weather_description'''
    fig=plt.figure(figsize=(6,4))
    sns.countplot(y='weather_description', data=df_traffic_data)
    st.pyplot(fig)
    
    '''## Exploring relationship between traffic and other features'''
    
    '''### Exploring traffic volume on holidays'''
    fig=plt.figure(figsize=(10,8))
    sns.boxplot(y='holiday',x='traffic_volume', data = holidays)
    st.pyplot(fig)
    
    '''### Plotting relationship between temp, rain_1h, snow_1h, cloud_all.'''
    num_vars = ['temp','rain_1h','snow_1h','clouds_all','traffic_volume']

    

    fig = px.scatter_matrix(df_traffic_data[num_vars],color='traffic_volume')
    st.plotly_chart(fig)
    '''### Plotting traffic volume over clouds_all'''
    fig=plt.figure(figsize=(14,8))
    sns.barplot(x='clouds_all', y = 'traffic_volume', data = df_traffic_data)
    st.pyplot(fig)
    
    '''### Plotting weather_main over traffic volume'''
    fig=plt.figure(figsize=(8,6))
    sns.barplot(x='weather_main', y = 'traffic_volume', data = df_traffic_data)
    st.pyplot(fig)
    
    
    '''### correlation between different numeric variables. plot shows no strong correlation between traffic and other variables'''
    
    fig=plt.figure(figsize=(8,6))
    sns.heatmap(df_traffic_data.corr(), annot=True)
    st.pyplot(fig)


if st.sidebar.checkbox("preprocessing and feature engineering"):
    st.subheader("convert date_time column to datetime type")
    raw.date_time = pd.to_datetime(raw.date_time)
    st.write(raw)
    st.subheader("extract month feature")
    months = raw.date_time.dt.month
    st.write(months)

    st.subheader("extract day of month feature") 
    day_of_months = raw.date_time.dt.day
    st.write(day_of_months)

    st.subheader("extract hour feature")

    hours = raw.date_time.dt.hour
    st.write(hours)

    st.subheader("first: extract the day name literal")
    to_one_hot = raw.date_time.dt.day_name()
    st.write(to_one_hot)
    st.subheader("second: one hot encode to 7 columns")
    days = pd.get_dummies(to_one_hot)
    st.write(days)

    st.subheader("utilize it along with apply method")
    # daypart function
    def daypart(hour):
        if hour in [2,3,4,5]:
            return "dawn"
        elif hour in [6,7,8,9]:
            return "morning"
        elif hour in [10,11,12,13]:
            return "noon"
        elif hour in [14,15,16,17]:
            return "afternoon"
        elif hour in [18,19,20,21]:
            return "evening"
        else: return "midnight"
    # utilize it along with apply method
    raw_dayparts = hours.apply(daypart)
    # one hot encoding
    dayparts = pd.get_dummies(raw_dayparts)
    # re-arrange columns for convenience
    dayparts = dayparts[['dawn','morning','noon','afternoon','evening','midnight']]
    #display data
    dayparts


    day_names = raw.date_time.dt.day_name()
    is_weekend = day_names.apply(lambda x : 1 if x in ['Saturday','Sunday'] else 0)

    # is_holiday flag
    is_holiday = raw.holiday.apply(lambda x : 0 if x == "None" else 1)

    # one-hot encode weather
    weathers = pd.get_dummies(raw.weather_main)
    #display data


    st.subheader("features table")
    st.subheader("first step: include features with single column nature")

    features = pd.DataFrame({
        'temp' : raw.temp,
        'rain_1h' : raw.rain_1h,
        'snow_1h' : raw.snow_1h,
        'clouds_all' : raw.clouds_all,
        'month' : months,
        'day_of_month' : day_of_months,
        'hour' : hours,
        'is_holiday' : is_holiday,
        'is_weekend' : is_weekend
    })
    st.write(features)
    st.subheader("second step: concat with one-hot encode typed features")
    features = pd.concat([features, days, dayparts, weathers], axis = 1)
    # target column
    st.write(features)
    target = raw.traffic_volume

if st.sidebar.button("Run the model and plot the result"):
#split data into training and test data
    X_train, X_test, y_train, y_test = train_test_split(features, target, test_size=0.2, shuffle = False)


    # define the model parameters
    params = {'n_estimators': 500,
            'max_depth': 4,
            'min_samples_split': 5,
            'learning_rate': 0.01,
            'loss': 'ls'}
    # instantiate and train the model
    gb_reg = ensemble.GradientBoostingRegressor(**params)
    gb_reg.fit(X_train, y_train)



    y_true = y_test
    y_pred = gb_reg.predict(X_test)


    fig, ax = plt.subplots(figsize = (12,6))
    index_ordered = raw.date_time.astype('str').tolist()[-len(X_test):][-100:]
    ax.set_xlabel('Date')
    ax.set_ylabel('Traffic Volume') 
    # the actual values
    ax.plot(index_ordered, y_test[-100:].to_numpy(), color='k', ls='-', label = 'actual')
    # predictions of model with engineered features
    ax.plot(index_ordered, gb_reg.predict(X_test)[-100:], color='b', ls='--', label = 'predicted; with date-time features')
    every_nth = 5
    for n, label in enumerate(ax.xaxis.get_ticklabels()):
        if n % every_nth != 0:
            label.set_visible(False)
    ax.tick_params(axis='x', labelrotation= 90)
    plt.legend()
    plt.title('Actual vs predicted on the last 100 data points')
    plt.draw()
    st.subheader("plot the result")
    st.pyplot(fig)


    def mape(true, predicted):        
        inside_sum = np.abs(predicted - true) / true
        return round(100 * np.sum(inside_sum ) / inside_sum.size,2)
    st.subheader("Error analysis")
    st.write(f"GB model MSE is {round(mean_squared_error(y_true, y_pred),2)}")
    st.write(f"GB model MAPE is {mape(y_true, y_pred)} %")
    st.write(f"GB model R2 is {round(r2_score(y_true, y_pred)* 100 , 2)} %")
    st.write(f"GB model R2 is {round(r2_score(y_true, y_pred)* 100 , 2)} %")
